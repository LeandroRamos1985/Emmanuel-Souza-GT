(function(root){
  const allowed=['utm_source','utm_medium','utm_campaign','utm_term','utm_content','gclid','fbclid'];
  root.Lead={
    campaign(query){const params=new URLSearchParams(query);return Object.fromEntries(allowed.filter(k=>params.has(k)).map(k=>[k,params.get(k).slice(0,200)]));},
    async send(endpoint,payload,request=fetch){
      if(!endpoint)throw Error('unconfigured');
      const url=new URL(endpoint);
      if(url.protocol!=='https:' && !(url.protocol==='http:'&&['localhost','127.0.0.1'].includes(url.hostname)))throw Error('https required');
      const control=new AbortController();const timer=setTimeout(()=>control.abort(),12000);
      try{const response=await request(url.href,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:control.signal,credentials:'omit',redirect:'error'});
        if(!response.ok)throw Error('delivery failed');
        const result=await response.json();if(result.success!==true)throw Error('confirmation missing');return true;
      }finally{clearTimeout(timer);}
    }
  };
})(globalThis);
