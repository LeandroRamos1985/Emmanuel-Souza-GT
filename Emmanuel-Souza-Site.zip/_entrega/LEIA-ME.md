# Emmanuel Souza — website completo

Site pronto para uso em servidor estático/GitHub Pages: index.html, en/, pt-br/, es/, assets/ e .nojekyll na raiz. Não requer npm ou compilação. Vídeos, retrato, fontes e três idiomas incluídos.

Repositório: https://github.com/LeandroRamos1985/Emmanuel-Souza-GT
Endereço da demonstração: https://leandroramos1985.github.io/Emmanuel-Souza-GT/pt-br/

Para consultar localmente, extraia o ZIP e sirva a pasta raiz com qualquer servidor HTTP estático (por exemplo python -m http.server 8080). Abra /pt-br/. Para publicar em outro repositório, preserve as pastas e ajuste canonical/hreflang/OG/sitemap para o endereço confirmado. Políticas e noindex estão apropriados à demonstração; a migração ao domínio oficial exige revisão específica.

Documentos, auditoria real dos 72 itens, evidências, fontes, licenças, plano e ferramentas estão em _entrega/. A pasta contém documentação da entrega e não é necessária ao runtime.

WhatsApp, telefone e e-mail usam dados reais. Sem endpoint configurado, o formulário mostra orientação honesta e abre WhatsApp; não envia ou salva os dados preenchidos. Para ativar atendimento online, configurar assets/config.js com gateway HTTPS que confirme {"success":true}, valide dados e aplique proteção server-side. Nenhum segredo pertence ao front-end. GA4 opcional exige analyticsId real e consentimento. LeadPilot não está conectado.
