# Seleção de mídia — Emmanuel Souza

## Vídeo selecionado antes da integração
Rafael Martinez, “Aerial View of Icon Park Ferris Wheel in Orlando”, Pexels 31248127.
Fonte: https://www.pexels.com/video/aerial-view-of-icon-park-ferris-wheel-in-orlando-31248127/
Arquivo observado na página: https://videos.pexels.com/video-files/31248127/13346130_2560_1440_30fps.mp4
Licença: https://www.pexels.com/license/ — uso em websites e edição permitidos, sem sugerir endosso. Material editorial de Orlando; não representa imóvel anunciado.

Pesquisa em 15/09/2026, antes de copiar a mídia para o site: ID 31248127 com “real estate” e “realtor”; ID 13346130 com “realtor realty”; autor e “Icon Park” com “realtor website”; nome exato do arquivo e slug, excluindo Pexels. Não foi localizado uso confirmado deste arquivo em outro site imobiliário nos resultados consultados. Resultados com números de imóveis não constituem identificação da mídia.

Comparação visual da primeira dobra: site atual de Emmanuel (família na piscina), Luxury Living Orlando (mansão ao entardecer), Lux Orlando (skyline), SERHANT Orlando (Lake Eola), referências do briefing e projeto Allan Freitas (dunas ao pôr do sol). A roda-gigante de Icon Park em primeiro plano, sob céu diurno, apresenta composição e assunto diferentes dos materiais observados. Não foram examinados integralmente todos os vídeos, páginas ou sites existentes. Não foi realizada busca reversa por upload; esta pesquisa não garante exclusividade mundial. Reavaliar e substituir se surgir uso igual ou visualmente semelhante em site do nicho.

## Rejeitados
Scott Portier 19423997 (Orlando) e 19319571 (Kissimmee): obras e edifícios em construção no primeiro plano, inadequados à direção visual aprovada.

## Identidade do cliente
Retrato real e marca do site fornecido pelo cliente. Retrato: https://www.casasvendaemorlando.com.br/wp-content/uploads/2022/10/casa-a-venda-em-orlando-logos1-1-335x361.png
Marca: https://www.casasvendaemorlando.com.br/wp-content/uploads/2022/01/casas-a-venda-em-orlando_emmanuel_logo_branco.png
Preservada a pessoa real. Compressão WebP; enquadramento CSS exclui os selos de avaliação abaixo do retrato. Não foram inventados depoimentos, notas, imóveis, preços ou fotografias de anúncios.

## Arquivos entregues
Vídeos H.264 de 16 segundos, sem áudio, versões desktop e mobile; posters derivados do mesmo vídeo. Fontes DM Sans locais com licença incluída. Favicon e arte social criados em SVG/composição gráfica para esta identidade.
